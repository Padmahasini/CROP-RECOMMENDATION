import { Component,OnInit } from '@angular/core';
import {MatTableDataSource} from '@angular/material/table';
@Component({
  selector: 'app-exports-statewise',
  templateUrl: './exports-statewise.component.html',
  styleUrls: ['./exports-statewise.component.scss']
})



 
export class ExportsStatewiseComponent implements OnInit  {

   state_exports : any[] = [{id:1,state:"Andhra Pradesh",exports:"Vegetables,Mango,Pulp,Grapes,Chili,Mangoes"},
  {id:2,state:"Arunachal Pradesh",exports:"Paddy, Millet, Wheat, Pulses, Potatoes, Sugarcane, Oilseeds, and Maize"},
  {id:3,state:"Assam",exports:"Lemon, Joha rice, Ginger, Pumpkin, Litchi , Bean, Brinjal, Turmeric, Betel nut, Rice"},
  {id:4,state:"Bihar",exports:"Rice,Mango,Guava,Litchi,Banana,beans,onion,chili,turmeric"},
  {id:5,state:"Chhattisgarh",exports:"Paddy, maize, jowar, groundnut, gram, and wheat"},
  {id:6,state:"Goa",exports:"Arecanut,Banana,Blackpepper,Cashewnut,Coconut"},
  {id:7,state:"Gujarat",exports:"Mangoes,Vegatables,Sesame seeds,Onions"},
  {id:8,state:"Haryana",exports:"Sugarcane, Ground nut, Paddy, Maize,Gram, Wheat, Barley and Oil seeds"},
  {id:9,state:"Himachal Pradesh",exports:"Apples"},
  {id:10,state:"Jharkhand",exports:"Vegetables"},
  {id:11,state:"Karnataka",exports:"Rice,sugarcane, Cashews, Cardamom, Betel (areca) nut, and Grapes"},
  {id:12,state:"Kerala",exports:"Spices,Tea ,Coconut,Horticulture,Medicinal Plants and Cashew"},
  {id:13,state:"Madhya Pradesh",exports:"Onion,garlic,Seed spices,Lentils,Wheat,Orange,Grams,Potatoes"},
  {id:14,state:"Maharashtra",exports:"Grape, Grape wine,Mangoes,Flowers,kesar Mango,Onion,Banana,Orange,Pomegranate"},
  {id:15,state:"Manipur",exports:"Pineapple, Orange, Mangoes, Lemons, Carrot, lLadies finger, Cabbage, and Pea "},
  {id:16,state:"Meghalaya",exports:"Oilseeds, Fodder, Bamboo and canes, dyes and spices, orchids,Arabica coffee and Kiwi"},
  {id:17,state:"Mizoram",exports:"Orange, Banana and Pineapple"},
  {id:18,state:"Nagaland",exports:"Rice, tobacco, Oilseeds, pulses, fibers, Potato and Sugarcane"},
  {id:19,state:"Odisha",exports:"Ginger and Turmeric"},
  {id:20,state:"Punjab",exports:"Gram, Barley, Wheat, fodder crops, Potatoes, Oil seeds, and winter vegetables"},
  {id:21,state:"Rajasthan",exports:"Coriander,Cumin"},
  {id:22,state:"Sikkim",exports:"Flowers,orchids,Cherry,pepper,ginger"},
  {id:23,state:"Tamil Nadu",exports:"Rice,Oil palm,Bananas, flowers, tapioca,Mangoes,coffee, sapota, tea and sugarcane"},
  {id:24,state:"Telangana",exports:"Rice,Cotton,Maize,sunflower,Green gram,turmeric,Mango"},
  {id:25,state:"Tripura",exports:"Pineapple, Orange, Cashew nut, Jackfruit, Coconut, Tea, Rubber, Forest , Plantations"},
  {id:26,state:"Uttar Pradesh",exports:"Rice, Wheat, maize, millet, gram, peas ,Barley, Sugarcane, Potato and lentils"},
  {id:27,state:"Uttarakhand",exports:"Basmati Rice,Vegatables,Potatoes,Mangoes"},
  {id:28,state:"West Bengal",exports:"Pineapple,Lychee,Darjeeling Tea,vegetables,Mangoes,Potatoes"}
  
  ];
  ut_exports : any[] = [{id:1,state:"Andaman and Nicobar Islands",exports:"Oilseed, pulses and vegetables"},
  {id:2,state:"Chandigarh",exports:"Wheat "},
  {id:3,state:"Dadra and Nagar Haveli and Daman and Diu",exports:"Paddy (Rice), ragi, small millets, jowar, sugarcanes, tomato, cauliflower, Mango, brinjal"},
  {id:4,state:"Delhi",exports:"Wheat, Jowar, bajra, sugarcane"},
  {id:5,state:"Jammu and Kashmir",exports:"Saffron,Apples, Apricots, Cherries, Pears, Walnuts,Rice, maize, millets, pulses, and Wheat"},
  {id:6,state:"Ladakh",exports:"Barley,Wheat, peas, vegetables and mustard for oil"},
  {id:7,state:"Lakshadweep",exports:"Jowar, ragi, sweet potatoes, sorgum and Banana"},
  {id:8,state:"Pondicherry",exports:"Bananas, flowers, tapioca, Coconut, groundnut and sugarcane"}];

  bigscreen : boolean = true;

  ngOnInit(): void {
    this.windowchange()
  }
  constructor(){
    
  }

  displayedColumns: string[] = ['ID','State Name','Exports'];
  dataSource = new MatTableDataSource(this.state_exports);

  displayedColumns1: string[] = ['ID','UT Name','Exports'];
  dataSource1 = new MatTableDataSource(this.ut_exports);


  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  applyFilter_ut(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource1.filter = filterValue.trim().toLowerCase();
  }
  
  windowchange() {
    if (window.innerWidth > 400) {
      this.bigscreen = true;
    }
    else {
      this.bigscreen = false;
    }
  }
}
