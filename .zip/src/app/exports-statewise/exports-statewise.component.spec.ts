import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExportsStatewiseComponent } from './exports-statewise.component';

describe('ExportsStatewiseComponent', () => {
  let component: ExportsStatewiseComponent;
  let fixture: ComponentFixture<ExportsStatewiseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExportsStatewiseComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ExportsStatewiseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
