import { Component, OnInit } from '@angular/core';
import Map from 'ol/Map.js';
import OSM from 'ol/source/OSM.js';
import TileLayer from 'ol/layer/Tile.js';
import View from 'ol/View.js';
import { fromLonLat, transform } from 'ol/proj.js';
import { Vector as VectorSource } from 'ol/source.js';
import { Vector as VectorLayer } from 'ol/layer.js';
import Draw from 'ol/interaction/Draw.js';
import { useGeographic } from 'ol/proj.js';
import { MatFormField, MatFormFieldControl } from '@angular/material/form-field';
import { CropRecommServiceService } from '../crop-recomm-service.service';
// import { ResultpageComponent } from '../resultpage/resultpage.component';
import { MatDialog } from '@angular/material/dialog';
import { InfodialogComponent } from '../infodialog/infodialog.component';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { boundingExtent, extend, getCenter } from 'ol/extent';

@Component({
  selector: 'app-map-display',
  templateUrl: './map-display.component.html',
  styleUrls: ['./map-display.component.scss']
})
export class MapDisplayComponent implements OnInit {

  title = 'map';
  zoom: any = 10;
  draw: any;
  latlongmap: any = [88.246521, 23.049039];
  // [88.246521, 23.049039];
  map: any;
  bigscreen: boolean = true;
  getcoord = false;
  offinteract: boolean = false;
  lat: any;
  long: any;
  councode: any = "";
  cityname: any = "";
  state: any = "";
  geocoderes: any;
  stcoun: any;
  loaded: boolean = false;
  firstFormGroup !: FormGroup; secondFormGroup !: FormGroup;
  isdraw : boolean = false;
  constructor(private http: CropRecommServiceService, public dialog: MatDialog, private _formBuilder: FormBuilder) {
    this.windowchange();

  }

  ngOnInit(): void {
    // document.getElementById('mapdetails').style.display = "none";

    this.viewmap();
    useGeographic();
    this.firstFormGroup = this._formBuilder.group({
      // firstCtrl: ['', Validators.required],
    });
    this.secondFormGroup = this._formBuilder.group({
      // secondCtrl: ['', Validators.required],
    });

  }

  raster = new TileLayer({
    source: new OSM(),
  });

  source = new VectorSource({ wrapX: false });

  vector = new VectorLayer({
    source: this.source,
    style: {
      'fill-color': 'rgba(255, 0, 0, 0.2)',
      'stroke-color': '#ffcc33',
      'stroke-width': 2,
      'circle-radius': 7,
      'circle-fill-color': '#ff0000',
    },

  });

  viewmap() {

    this.map = new Map({

      layers: [this.raster, this.vector],
      target: 'map',
      view: new View({
        center: transform(this.latlongmap, 'EPSG:4326', 'EPSG:3857'),
        
        zoom: 10,
        minZoom: 7,
        maxZoom: 17,
        
      }),
    });
   
    this.loaded = true;
    setTimeout(() => {
      this.map.updateSize();
     this.map.getView().setCenter(this.latlongmap);
    }, 300);
    // let a = this.getcoordmap(event);

  }

  getcoordmap(event: any) {
    let coordinate: any;
    if (this.getcoord == true) {
      coordinate = this.map.getEventCoordinate(event);
      this.long = coordinate[0].toString().slice(0, 5);
      this.lat = coordinate[1].toString().slice(0, 5);

      // document.getElementById('mapdetails').style.display = "block";

      this.stcoun = " , ";

      this.http.getcityname(coordinate[1], coordinate[0]).subscribe({
        next: (data: any) => {
          if (data == "undefined" || data == "" || data == "null") {
            this.cityname = "";
            this.councode = "";
            this.state = "";
            this.stcoun = "";
          }
          else {
            this.geocoderes = data[0];

            this.cityname = this.geocoderes.name;
            this.councode = this.geocoderes.country;
            this.state = this.geocoderes.state;
          }
          
        }, error: () => {
          alert("Error in geocoding");
        }
      });
    }
    // this.map.removeInteraction(this.draw);
  }

  selectoption(optval: any, event: any) {

    if (this.draw != undefined) {
      window.location.reload();
    }
    this.draw = new Draw({
      source: this.source,
      type: optval,
      stopClick: true,

    });

    this.map.addInteraction(this.draw);
    
  }

  isdrawres(event:any){
    if(this.draw == undefined || this.draw == 'undefined'){
      alert("Please select valid location in map!");
      this.resetmap();
    }
    
  }
  submitmap() {
    this.getcoord = true;
    this.getcoordmap(event);
    this.next_btn();
  }
  next_btn() {
    this.map.removeInteraction(this.draw);
  }
  zoomin() {
    this.map.getView().animate({
      zoom: this.map.getView().getZoom() + 1,
      duration: 250
    })
  }
  zoomout() {

    this.map.getView().animate({
      zoom: this.map.getView().getZoom() - 1,
      duration: 250
    })
  }

  resetmap() {
    window.location.reload();
    this.map.getLayers().forEach((layer: { getSource: () => { (): any; new(): any; refresh: { (): any; new(): any; }; }; }) => layer.getSource().refresh());
  }


  windowchange() {
    if (window.innerWidth > 400) {

      this.zoom = 13;
      this.latlongmap = [77.22445, 28.63576];
      // this.latlongmap = [85.246521, 23.049039];
      this.bigscreen = true;
    }
    else {
      this.zoom = 13;
      this.latlongmap = [77.22445, 28.63576];
      this.bigscreen = false;
    }
  }

  result() {
    if (this.lat == null || this.long == null) {
      return true;
    }
    else {
      return false;
    }
  }

  cancelbtn() {
    this.lat = null;
    this.long = null;
    this.cityname = "";
    this.councode = "";
    this.state = "";
    this.stcoun = ""
    this.result();
    // this.stcoun = "";document.getElementById('mapdetails').style.display = "none";
  }

  // search(){
  //   let geocoder = new Geocoder('nominatim', {
  //     provider: 'osm', //change it here
  //     lang: 'en-US',
  //     placeholder: 'Search for ...',
  //     targetType: 'text-input',
  //     limit: 5,
  //     keepOpen: true
  //   });

  // }

  infomap() {
    const dialogRef = this.dialog.open(InfodialogComponent);

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }


}
