import { TestBed } from '@angular/core/testing';

import { CropRecommServiceService } from './crop-recomm-service.service';

describe('CropRecommServiceService', () => {
  let service: CropRecommServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CropRecommServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
