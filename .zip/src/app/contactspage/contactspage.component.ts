import { Component,OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder, FormControlName } from '@angular/forms'
import emailjs, { EmailJSResponseStatus } from '@emailjs/browser';
@Component({
  selector: 'app-contactspage',
  templateUrl: './contactspage.component.html',
  styleUrls: ['./contactspage.component.scss']
})
export class ContactspageComponent implements OnInit{
  contactform !: FormGroup;
 
  constructor(private fb:FormBuilder ){

  }
  ngOnInit(): void {
    
    
    this.contactform = this.fb.group({
      emailid : ['',[Validators.required,Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]],
      message : ['',Validators.required],
      from_name:['',Validators.required]

    })
  }
  onSubmit(e:Event){
   
    e.preventDefault();
    emailjs.sendForm('service_6rv285c', 'template_5hinfor',e.target as HTMLFormElement , 'v5Mi6JzBncFF6Ae_w')
      .then((result: EmailJSResponseStatus) => {
        alert("Form Submitted Successfully!");
      }, (error) => {
        console.log(error.text);
        alert("Error in submitting the form")
      });
    
    this.onClear();
      
  }
  onClear() {
    this.contactform.setValue({
      emailid : '',
      message : '',
      from_name:''
    });
  }
}
