import { Component, OnInit } from '@angular/core';
import { CropRecommServiceService } from '../crop-recomm-service.service';
import { DatePipe } from '@angular/common';
import * as Chart from 'chart.js';
import * as XLSX from 'xlsx';
import { Input } from '@angular/core';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { toArray } from 'rxjs';
@Component({
  selector: 'app-resultpage',
  templateUrl: './resultpage.component.html',
  styleUrls: ['./resultpage.component.scss']
})
export class ResultpageComponent {

  op: any; lat: any; long: any;
  latlongres: any;
  myChart: Chart | undefined;
  myChart1: Chart | undefined;
  geocoderes: any; cityname: any; councode: any; state: any;
  pipe = new DatePipe('en-US');
  ctx: any;
  m_res_data: any;
  obj: any;
  date_obj: any;
  maxobj: any;
  minobj: any;
  dataValue = [];
  dataName = [];
  dataMaxtemp = [];
  dataMintemp = [];
  humidityarr = [];
  g = []; h = []; min = []; res_address: any;
  g1 = []; h1 = []; min1 = []; res_address1: any;
  date_obj1: any;
  obj1: any;
  m_res_data1: any;
  humidity: any;
  ctx1: any;
  bigscreen: boolean = false;
  latnum: number;
  longnum: number; dataName1 = [];
  humsmallscr = [];
  tempsmallscr = [];
  mean_ph: any;
  ph_result: boolean = false;
  dailymaxtemp : any;
  dailymintemp : any;
  panelOpenState = false;
  head_to_disp = ["Crop Name",
  "Min pH", 
  "Max pH",
  "Min Temp",
  "Max Temp",
  "North India Growing Season",
  "South India Growing Season",
  "Planting Method",
  "Sowing Depth (inches)",
  "Sowing Distance (inches/feet)",
  "Days to Maturity"]
  
  constructor(private http: CropRecommServiceService) {

  }


  ngOnInit(): void {

  }
  ngAfterViewInit(): void {
    let scc = this.windowchange();
    
    this.getlatlongdata();

    
  }
  getinitiaiseval() {

    this.dataValue = [];
    this.dataMaxtemp = [];
    this.dataMintemp = [];
    this.dataName = [];
    this.ctx = '';
    this.res_address = '';
  }

  get_monthforecast_res() {

    this.g = []; this.h = []; this.min = [];
    this.ctx = document.getElementById('myChart');

    this.http.getweatherdata(this.latnum, this.longnum).subscribe(data => {
      this.m_res_data = data;
      this.res_address = this.cityname;

      for (let m_i = 0; m_i < 40; m_i++) {
        let formatdate = this.changedateformat((this.m_res_data[m_i].dt));
        // this.humidityarr.push((this.m_res_data[m_i].main.humidity));


        this.date_obj = {
          // dt: this.pipe.transform((this.m_res_data[m_i].dt), 'dd-MM-yy'),
          dt: formatdate,
        }
        this.maxobj = {
          x: formatdate,
          y: (((this.m_res_data[m_i].main.temp_max).toFixed(0)) - 273.15).toFixed(0)

        }
        this.minobj = {
          x: formatdate,
          y: (((this.m_res_data[m_i].main.temp_min).toFixed(0)) - 273.15).toFixed(0)

        }

        this.dataName.push(this.date_obj as never);
        this.dataMaxtemp.push(this.maxobj as never);
        this.dataMintemp.push(this.minobj as never);

      }

      this.h = [];
      let num = 40
      for (let p = 0; p < num; p++) {
        this.g.push(this.dataMaxtemp[p]);
      }
      for (let min = 0; min < num; min++) {
        this.min.push(this.dataMintemp[min]);
      }
      for (let q = 0; q < num; q++) {
        this.h.push(this.dataName[q]['dt']);
      }
      for (let r = 0; r < num; r++) {
        this.tempsmallscr.push([this.g[r].x, this.g[r].y, this.min[r].y])
      }
      
      if (this.bigscreen) {
        this.ctx = document.getElementById('myChart');
        if (this.myChart) { this.myChart.destroy(); }
        this.myChart = new Chart(this.ctx, {
          type: 'bar',
          data: {
            labels: this.h,
            datasets: [{
              label: 'Max Temperature (℃)',
              data: this.g,
              backgroundColor: 'rgba(255, 159, 64, 0.7)',
              borderColor: 'rgba(255, 99, 132, 1)',
              borderWidth: 2,

            },
            {
              label: 'Min Temperature (℃)',
              data: this.min,
              backgroundColor: 'rgba(54, 162, 235, 0.7)',
              borderColor: 'rgba(54, 162, 235, 1)',
              borderWidth: 2
            }
            ]

          },
          options: {
            scales: {
              yAxes: [{
                ticks: {
                  beginAtZero: false,
                },
                scaleLabel: {
                  display: true,
                  labelString: 'Temperature (℃)'
                }

              }],
              xAxes: [{
                scaleLabel: {
                  display: true,
                  labelString: '5 days timely forecast of ' + this.res_address

                }

              }]
            }
          }
        });

        // return "";
      }
    }, err => {
      console.log(err);
      // alert("Enter valid city name");
      return "";
    });
  }

  getlatlongdata() {
    if (this.http.getlatlong() != null) {
      this.http.getlatlong().subscribe({
        next: (data: any) => {
          this.geocoderes = data[0];
          this.cityname = this.geocoderes.name;
          this.councode = this.geocoderes.country;
          this.state = this.geocoderes.state;
          this.op = this.cityname + "," + this.state + "," + this.councode;
          this.lat = this.geocoderes.lat.toString().slice(0, 5);
          this.long = this.geocoderes.lon.toString().slice(0, 5);
          this.latnum = this.geocoderes.lat;
          this.longnum = this.geocoderes.lon;
          this.getdailytempfn();
          this.get_monthforecast_res();
          this.croprecommfn();
        }, error: () => {
          alert("Error in getting lat long for given point");
        }
      })

    }
  }

  changedateformat(p_date: any) {
    var date = new Date(p_date * 1000);

    var time = this.pipe.transform(date.getTime(), 'hh-mm');
    var dateObject = ('0' + date.getDate()).slice(-2) + '/' + ('0' + (date.getMonth() + 1)).slice(-2) + '/' + date.getFullYear() + ' ' + time;

    return dateObject;
  }

  get_humidity_forecast() {


    this.g1 = []; this.h1 = []; this.min1 = [];
    this.ctx1 = document.getElementById('myChart1');


    this.http.getweatherdata(this.latnum, this.longnum).subscribe(data => {
      this.m_res_data1 = data;
      this.res_address1 = this.cityname;

      for (let m_i = 0; m_i < 40; m_i++) {
        let formatdate1 = this.changedateformat((this.m_res_data[m_i].dt));
        this.date_obj1 = {
          // dt: this.pipe.transform((this.m_res_data[m_i].dt), 'dd-MM-yy'),
          dt: formatdate1,
        }
        this.humidity = {
          x: formatdate1,
          y: (((this.m_res_data1[m_i].main.humidity)))

        }
        this.dataName1.push(this.date_obj1 as never);
        this.humidityarr.push(this.humidity as never);

      }

      this.h1 = [];
      let num = 40
      for (let p = 0; p < num; p++) {
        this.g1.push(this.humidityarr[p]);
      }

      for (let q = 0; q < num; q++) {
        this.h1.push(this.dataName1[q]['dt']);
      }


      for (let r = 0; r < num; r++) {
        this.humsmallscr.push([this.g1[r].x, this.g1[r].y])
      }

      if (this.bigscreen) {
        this.ctx1 = document.getElementById('myChart1');
        if (this.myChart1) { this.myChart1.destroy(); }
        this.myChart1 = new Chart(this.ctx1, {
          type: 'bar',
          data: {
            labels: this.h1,
            datasets: [{
              label: 'Humidity (%)',
              data: this.g1,
              backgroundColor: 'rgba(54, 162, 235, 0.7)',
              // borderColor: 'rgba(255, 99, 132, 1)',
              borderWidth: 2,

            },

            ]
          },
          options: {
            scales: {
              yAxes: [{
                ticks: {
                  beginAtZero: false,
                },
                scaleLabel: {
                  display: true,
                  labelString: 'Humidity (℃)'
                }

              }],
              xAxes: [{
                scaleLabel: {
                  display: true,
                  labelString: '5 days timely humidity of ' + this.res_address1

                }

              }]
            }
          }
        });
        // return "";
      }
    }, err => {
      console.log(err);

      // alert("Enter valid city name");
      return "";
    });
  }



  onChange(event: MatTabChangeEvent) {
    const tab = event.tab.textLabel;

    if (tab === "Humidity Details") {
      this.get_humidity_forecast()
    }
    else if (tab === "Temperature Details") {
      this.get_monthforecast_res()
    }

  }

  windowchange() {
    if (window.innerWidth > 400) {
      this.bigscreen = true;
    }
    else {
      this.bigscreen = false;
    }
  }

get_crop_info = [];
  croprecommfn() {
    
    this.http.soilgridservice(this.latnum, this.longnum).subscribe(data => {
      this.mean_ph = parseFloat(data.properties.layers[0].depths[0].values.mean);
      if (isNaN(this.mean_ph)) {
        this.ph_result = false;
        console.log("Please donot select urban or sea area");
      }
      else {
        // To get min mean temp
        
        this.mean_ph = this.mean_ph / 10;
        this.http.readtextfile().subscribe(textres => {
          let lines = textres.split("\n");
          for (let l = 1; l < lines.length; l++) {
            let spl_tab = lines[l].split("\t");
            let arr2 = [spl_tab];
            for (let sp = 0; sp < arr2.length; sp++) {
              let line_data = arr2[sp];
              let min_ph = line_data[1];
              let max_ph = line_data[2];
              let min_temp = parseFloat(line_data[3]);
              let max_temp = parseFloat(line_data[4]);
              
               if ((this.mean_ph >= min_ph && this.mean_ph <= max_ph) && (min_temp <= this.dailymintemp) && (max_temp >= this.dailymaxtemp)) {
               
                this.get_crop_info.push(line_data);

              }


            }
          }
        });


      }

    })


  }

  getdailytempfn(){
    this.http.getdailytemp(this.latnum,this.longnum).subscribe(dailytemp=>{
      console.log(dailytemp);
      
          this.dailymaxtemp = (dailytemp.main.temp_max-273.15).toFixed(0);
          this.dailymintemp = (dailytemp.main.temp_min-273.15).toFixed(0);
     })
  }
}
