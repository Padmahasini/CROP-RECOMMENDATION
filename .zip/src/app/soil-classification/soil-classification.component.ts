import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-soil-classification',
  templateUrl: './soil-classification.component.html',
  styleUrls: ['./soil-classification.component.scss']
})
export class SoilClassificationComponent implements OnInit{
    soil_class = [{"soiltype":"Alluvial","statesfound":"Mainly found in the plains of Gujarat,  Punjab, Haryana, UP, Bihar, Jharkhand etc.","richin":"Potash and Lime","lacksin":"LimeNitrogen and Phosphorous","cropsgrown":"Large variety of rabi and kharif crops such as wheat, rice, sugarcane, cotton, jute etc"},
    {"soiltype":"Black (Regur soil)","statesfound":"Deccan plateau- Maharashtra, Madhya Pradesh, Gujarat, Andhra Pradesh,Tamil Nadu, Valleys of Krishna and Godavari.Lime","richin":"Lime, Iron, Magnesia and Alumina, Potash","lacksin":"Phosphorous, Nitrogen and organic matter","cropsgrown":"Cotton, sugarcane, jowar, tobacco, wheat, rice etc."},
    {"soiltype":"Red","statesfound":"Eastern and southern part of the deccan plateau, Orissa, Chattisgarh and southern parts of the middle Ganga plain.","richin":"Iron and Potash","lacksin":"Nitrogen, Phosphorous and humus.","cropsgrown":"Wheat, rice, cotton, sugarcane and pulses"},
    {"soiltype":"Laterite","statesfound":"Karnataka, Kerala, Tamilnadu, Madhya Pradesh, Assam and Orissa hills.","richin":"Western Rajastan, north Gujarat and southern Punjab","lacksin":"Organic matter, Nitrogen, Phosphate and Calcium","cropsgrown":"Cashewnuts, tea, coffee, rubber"},
    {"soiltype":"Arid and Desert","statesfound":"Western Rajastan, north Gujarat and southern Punjab","richin":"Soluble salts, phosphate","lacksin":"Humus, Nitrogen","cropsgrown":"Only drought resistant and salt tolerant crops such as barley, rape, cotton, millets maize and pulses"},
    {"soiltype":"Saline and Alkaline","statesfound":"Western Gujarat, deltas of eastern coast, Sunderban areas of West Bengal, Punjab and Haryana","richin":"Sodium, Potassium, Magnesium","lacksin":"Nitrogen and Calcium","cropsgrown":"Unfit for agriculture"},
    {"soiltype":"Mountain Soil","statesfound":"Jammu & Kasmir,Sikkim,Arunachal Pradesh,Himachal Pradesh, and Uttaranchal","richin":"humus","lacksin":"potash, phosphorus, and lime","cropsgrown":"Fertile in lower slopes, timbers,rice and tea"}
    
  ]
  bigscreen : boolean = false;
  constructor(){

  }
  ngOnInit(): void {
   this.windowchange();
  }
  displayedColumns1 : string[] | undefined;
  dataSource1 : any;

  windowchange() {
    if (window.innerWidth > 400) {
      this.bigscreen = true;
       this.displayedColumns1 = ['soiltype','statesfound','richin','lacksin','cropsgrown'];
        this.dataSource1 = new MatTableDataSource(this.soil_class);
    }
    else {
      this.bigscreen = false;
       this.displayedColumns1= ['soiltype','statesfound','cropsgrown'];
      this.dataSource1 = new MatTableDataSource(this.soil_class);
    }
  }
}
