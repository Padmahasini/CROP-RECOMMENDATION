import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { ContactspageComponent } from './contactspage/contactspage.component';
import { ExportsStatewiseComponent } from './exports-statewise/exports-statewise.component';
import { HomepageComponent } from './homepage/homepage.component';
import { MapDisplayComponent } from './map-display/map-display.component';
import { ResultpageComponent } from './resultpage/resultpage.component';
import { SoilClassificationComponent } from './soil-classification/soil-classification.component';

const routes: Routes = [
  {
    path:'home',component:AppComponent,
  
    children:[{
      path:'',component:HomepageComponent
    },
    {
      path:'viewmap',component:MapDisplayComponent
    },
      {
      path:'export_statewise',component:ExportsStatewiseComponent
    },
    {
      path:'soil_classification',component:SoilClassificationComponent
    },
    {
      path:'croprecommpage',component:ResultpageComponent
    },
    {
      path:'contacts',component:ContactspageComponent
    }
  ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
