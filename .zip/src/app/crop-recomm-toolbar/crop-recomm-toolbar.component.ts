import { Component,OnInit } from '@angular/core';

@Component({
  selector: 'app-crop-recomm-toolbar',
  templateUrl: './crop-recomm-toolbar.component.html',
  styleUrls: ['./crop-recomm-toolbar.component.scss']
})
export class CropRecommToolbarComponent {
  bigscreen : boolean = false;
    constructor(){

    }
    ngOnInit(): void {
      this.windowchange();
     }
    windowchange() {
      if (window.innerWidth > 400) {
        this.bigscreen = true;
         
      }
      else {
        this.bigscreen = false;
        
      }
    }
}
