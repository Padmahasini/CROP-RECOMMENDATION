import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CropRecommToolbarComponent } from './crop-recomm-toolbar.component';

describe('CropRecommToolbarComponent', () => {
  let component: CropRecommToolbarComponent;
  let fixture: ComponentFixture<CropRecommToolbarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CropRecommToolbarComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CropRecommToolbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
