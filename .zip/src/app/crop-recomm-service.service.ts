import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
let apikey = "bcbe1deb15dca6bdc734c01fda19b5d7";
let baseurl : string = 'https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/';
let monthurl : string = 'unitGroup=us&include=30&key=V9ZTYYE8QJVYBREXPK7B8M8VH&contentType=json';
@Injectable({
  providedIn: 'root'
})
export class CropRecommServiceService {
  file: string ='app/assets/croptxt.txt';

  constructor(private http:HttpClient) {

   }
   rest : any;
  
   getcityname(lat:number,long:number){
     this.rest =  this.http.get<any>("http://api.openweathermap.org/geo/1.0/reverse?lat="+lat+"&lon="+long+"&limit=1&appid="+apikey);
    return this.rest;
    
   }

   getlatlong(){
    
      if(this.rest != null){
        return this.rest;
   }
  }

  getweatherdata(latitude:number,longitude:number){
    // return this.http.get(baseurl+"latitude="+latitude+'?longitude='+longitude+'?'+monthurl);
   return this.http.get<any>("https://api.agromonitoring.com/agro/1.0/weather/forecast?lat="+latitude+"&lon="+longitude+"&appid=cc01f73d5c324b252a341e58a3093433")
  }
  
  readtextfile(){
    return this.http.get('assets/croptxt.txt', {responseType: 'text'})
  }

  soilgridservice(lat:any,long:any){
    return this.http.get<any>("https://rest.isric.org/soilgrids/v2.0/properties/query?lon="+long+"&lat="+lat+"&property=phh2o&depth=0-5cm&value=mean")
  
  }

  getdailytemp(lat:any,long:any){
    return this.http.get<any>("https://api.openweathermap.org/data/2.5/weather?lat="+lat+"&lon="+long+"&appid=bcbe1deb15dca6bdc734c01fda19b5d7")
  }
}

