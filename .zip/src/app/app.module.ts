import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatButtonModule} from '@angular/material/button';
import { MapDisplayComponent } from './map-display/map-display.component';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatIconModule} from '@angular/material/icon';
import { MatFormFieldModule, MatLabel} from '@angular/material/form-field';
import { HttpClientModule } from '@angular/common/http';
import { CropRecommToolbarComponent } from './crop-recomm-toolbar/crop-recomm-toolbar.component';
import {MatMenuModule} from '@angular/material/menu';
import { ExportsStatewiseComponent } from './exports-statewise/exports-statewise.component';
import {MatTableModule} from '@angular/material/table';
import {MatTabsModule} from '@angular/material/tabs';
import { SoilClassificationComponent } from './soil-classification/soil-classification.component';
import { ResultpageComponent } from './resultpage/resultpage.component';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatDialogModule} from '@angular/material/dialog';
import { InfodialogComponent } from './infodialog/infodialog.component';
import { HomepageComponent } from './homepage/homepage.component';
import {MatStepperModule} from '@angular/material/stepper';
import { ReactiveFormsModule } from '@angular/forms';
import { MatInputModule } from "@angular/material/input";
import { ContactspageComponent } from './contactspage/contactspage.component';

@NgModule({
  declarations: [
    AppComponent,
    MapDisplayComponent,
    CropRecommToolbarComponent,ExportsStatewiseComponent, SoilClassificationComponent, ResultpageComponent, InfodialogComponent, HomepageComponent, ContactspageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,MatToolbarModule,MatFormFieldModule,
    BrowserAnimationsModule,MatButtonModule,MatIconModule,HttpClientModule,MatMenuModule,MatTableModule,MatTabsModule,MatExpansionModule,
    MatDialogModule,MatStepperModule,ReactiveFormsModule,MatInputModule
  ],
  // providers: [ResultpageComponent,MapDisplayComponent],
  bootstrap: [AppComponent]
  // exports:[ResultpageComponent,MapDisplayComponent]
})
export class AppModule { }
